#!/bin/bash 
cat /scripts/gato.txt


